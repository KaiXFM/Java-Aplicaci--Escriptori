
package uf5.pkg6.projecte.basedades;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import uf5.pkg6.projecte.streamin.model.Compte;
import java.sql.ResultSet;
import org.mariadb.jdbc.Connection;


public class CompteDAO {
    
    public ArrayList<Compte> obtenirComptesModalitatBD(int id_modalitat){
    
    Connection con = (Connection) ConexioBDSingleton.getConnection();
    
    ArrayList<Compte> comptes = new ArrayList();
    
    String sentenciaSql = null;
    
    if (id_modalitat  ==  1) {
        sentenciaSql = "SELECT Compte.id_compte, Clients.id_client, Clients.DNI, Clients.nom, Compte.data_alta, Compte.id_modalitat "
                + "FROM Compte INNER JOIN Clients ON Compte.id_client = Clients.id_client"
                + " WHERE Compte.id_modalitat= ?"
                + " AND Compte.id_client = Clients.id_client";
    } else if (id_modalitat == 2){
        sentenciaSql = "SELECT Compte.id_compte, Clients.id_client, Clients.DNI, Clients.nom, Compte.data_alta, Compte.id_modalitat "
                + "FROM Compte INNER JOIN Clients ON Compte.id_client = Clients.id_client"
                + " WHERE Compte.id_modalitat = ?"
                + " AND Compte.id_client = Clients.id_client";
    }else if (id_modalitat == 3){
         sentenciaSql = "SELECT Compte.id_compte, Clients.id_client, Clients.DNI, Clients.nom, Compte.data_alta, Compte.id_modalitat "
                + "FROM Compte INNER JOIN Clients ON Compte.id_client = Clients.id_client"
                + " WHERE Compte.id_modalitat = ?"
                + " AND Compte.id_client = Clients.id_client";
    }else{
        sentenciaSql = "SELECT Compte.id_compte, Clients.id_client, Clients.DNI, Clients.nom, Compte.data_alta, Compte.id_modalitat "
                + "FROM Compte INNER JOIN Clients ON Compte.id_client = Clients.id_client";
    }
    
    try (java.sql.PreparedStatement ps = con.prepareStatement(sentenciaSql)){
        if (id_modalitat != 0)  ps.setInt(1, id_modalitat);
        ResultSet rs = ps.executeQuery();
            
        while (rs.next()){
            Compte c = new Compte();
            c.setIdCompte(rs.getInt("compte.id_compte"));
            c.setIdClient(rs.getInt("clients.id_client"));
            c.setDNI(rs.getString("clients.DNI"));
            c.setNom(rs.getString("clients.nom"));
            c.setDataAlta(rs.getDate("compte.data_alta"));
            c.setIdModalitat(rs.getInt("compte.id_modalitat"));
            comptes.add(c);
        }
    }   catch (SQLException ex) {
            Logger.getLogger(CompteDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
    return comptes;
}
    
}
