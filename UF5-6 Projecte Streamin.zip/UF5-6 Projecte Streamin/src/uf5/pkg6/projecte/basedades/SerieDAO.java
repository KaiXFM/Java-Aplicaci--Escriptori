
package uf5.pkg6.projecte.basedades;

import uf5.pkg6.projecte.streamin.model.Serie;
import java.sql.*;
import java.util.logging.Level;
import java.util.logging.Logger;
public class SerieDAO {
    
    public Serie consultaSerieBD(int id){
        Connection con = ConexioBDSingleton.getConnection();
        
        Serie s = null;
        
        String senteciaSql = " SELECT COUNT(Episodi.id_produccio) AS numcapitols, SUM(Episodi.durada) AS duradatotal" 
                + " FROM Series INNER JOIN Episodi ON Series.id_produccio = Episodi.id_produccio"
                + " WHERE Series.id_produccio = ?"
                + " AND Series.id_produccio = Episodi.id_produccio";
        
        try( PreparedStatement ps = con.prepareStatement(senteciaSql)){
                
                ps.setInt(1, id);
                ResultSet rs = ps.executeQuery();
                if (rs.next()) {
                    s = dadesBDSerie(id,rs);
                }

    
    }   catch (SQLException sqle) {
            sqle.printStackTrace();
        }
        return s;
}
    
    private Serie dadesBDSerie(int id, ResultSet rs) throws SQLException{
        Serie s = new Serie();
        s.setId(id);
        s.setDuradaTotal(rs.getDouble("duradatotal"));
        s.setNumCapitols(rs.getInt("numcapitols"));
        
        s.afegirCategoria(obtenirCategoria(id));
        s.afegirDirector(obtenirDirector(id));
        s.afegirActor(obtenirActor(id));
        
        return s;
    }
    
    private String obtenirCategoria(int idProduccio){
    
        Connection con = ConexioBDSingleton.getConnection();
        
        String categoria = " ";
        
        String sentenciaSql = "SELECT genere.nom"
                + " FROM genere INNER JOIN pertany ON genere.id_categoria = pertany.id_categoria"
                + " WHERE pertany.id_produccio = ?";
        
        try (PreparedStatement ps = con.prepareStatement(sentenciaSql)){
            
            ps.setInt(1, idProduccio);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                    return rs.getString("nom");
            }
        } catch (SQLException ex) {
            Logger.getLogger(SerieDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        return categoria;
    }
    
    private String obtenirDirector(int idProduccio){
    
        Connection con = ConexioBDSingleton.getConnection();
        
        String director = " ";
        
        String sentenciaSql = "SELECT Director.nom_director"
                + " FROM dirigeix_pelicula, Director"
                + " WHERE dirigeix_pelicula.id_director = ?"
                + " AND dirigeix_pelicula.id_director = Director.id_director";
        
        try (PreparedStatement ps = con.prepareStatement(sentenciaSql)){
            
            ps.setInt(1, idProduccio);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                    return rs.getString("nom_director");
            }
        } catch (SQLException ex) {
            Logger.getLogger(SerieDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        return director;
    }
    
    private String obtenirActor(int idProduccio){
    
        Connection con = ConexioBDSingleton.getConnection();
        
        String actor = " ";
        
        String sentenciaSql = "SELECT actors.nom_actor"
                + " FROM actors INNER JOIN actuen ON actors.id_actor = actuen.id_actor"
                + " WHERE actuen.id_produccio = ?";
        
        try (PreparedStatement ps = con.prepareStatement(sentenciaSql)){
            
            ps.setInt(1, idProduccio);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                    return rs.getString("nom_actor");
            }
        } catch (SQLException ex) {
            Logger.getLogger(SerieDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        return actor;
    }
}



